test = {
  'name': 'Assignment',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""

          """,
          'hidden': True,
          'locked': False
        }
      ],
      'scored': False,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
